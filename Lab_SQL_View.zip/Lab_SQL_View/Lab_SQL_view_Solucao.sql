-- (a)	Quem são os clientes que moram em cidades onde existem agências do banco?
select customer_name
from customer where customer_city IN
	(select branch_city from branch);
-- ou
select distinct customer_name
from customer, branch
where branch_city = customer_city;
-- ou
select distinct customer_name
from customer 
	join branch on branch_city = customer_city;

-- (b)	Quem são os clientes que têm um empréstimo numa agência da mesma cidade onde moram?
select customer_name
from customer 
	natural join borrower 
	natural join loan 
	natural join branch
where branch_city = customer_city;

-- (c)	Quais são os nomes e moradas dos clientes que têm conta no banco, mas não tem empréstimos?
select c.customer_name, customer_street, customer_city
from customer c
where customer_name in ( 
    select customer_name
    from depositor)
and customer_name not in (
    select customer_name
    from borrower);
-- ou

select c.customer_name, customer_street, customer_city
from customer c
where exists( 
    select * 
    from depositor 
    where customer_name = c.customer_name)
and not exists(
    select *
    from borrower
    where customer_name = c.customer_name);

-- ou
    
select distinct customer_name, customer_street, customer_city
from depositor natural join customer
where customer_name not in
	(select customer_name from borrower);


-- (d)	Quantos clientes moram na mesma cidade de uma agência onde tenham conta?
select count(distinct (customer_name)) as num_cli
from customer 
	natural join depositor 
	natural join account 
	natural join branch
where branch_city = customer_city;

-- (e)	Quantos clientes têm pelo menos uma conta e um empréstimo no banco?
select count(distinct(customer_name)) as num_cli
from depositor natural join borrower;

-- (f)	Qual o nome dos clientes que têm mais do que um empréstimo?
select distinct(b1.customer_name)
from borrower b1, borrower b2
where b1.customer_name=b2.customer_name 
  and b1.loan_number<>b2.loan_number;

-- ou 

select customer_name
from borrower  
group by customer_name
having count(*)>1;

-- (g)	Liste por ordem alfabética os nomes dos clientes que têm mais de duas contas no banco.
select distinct customer_name
from depositor
group by customer_name
having count(account_number) > 2
order by customer_name ASC;

-- (h)	Qual o nome do cliente que mais dinheiro deve ao banco (no total dos seus empréstimos)?
select customer_name
from loan natural join borrower
group by customer_name
having sum(amount) >= ALL
    (select sum(amount)
    from  loan natural join borrower
	  group by customer_name);

-- (i)	Qual é o nome e morada do cliente que tem o maior saldo no total das suas contas?
select customer_name, customer_city, customer_street
from customer 
	natural join depositor 
	natural join account
group by customer_name
having sum(balance) >= ALL
    (select sum(balance)
    from depositor natural join account
	  group by customer_name);

-- (j)	Qual é a agência que tem mais contas?
select branch_name
from account
group by branch_name
having count(*) >= ALL
	(select count(*)
    from account
    group by branch_name);

-- (k)	Qual é a agência cujo saldo médio das contas é o maior entre todas as agências?
select branch_name
from account
group by branch_name
having avg(balance) >= ALL (
	select avg(balance)
	from account
	group by branch_name);

-- (l) Qual o numero de clientes por cidade de agência
select branch_city, count(distinct customer_name)
from(
    select customer_name, branch_city
    from depositor natural join account natural join branch
    union
    select customer_name, branch_city
    from borrower natural join loan natural join branch) as customer_contracts
group by branch_city

-- (m) Qual é a cidade com mais clientes no total das suas agências?
select branch_city, count(distinct customer_name)
from(
    select customer_name, branch_city
    from depositor natural join account natural join branch
    union
    select customer_name, branch_city
    from borrower natural join loan natural join branch) as customer_contracts
group by branch_city
having count(distinct customer_name) > all (
	select count(distinct customer_name)
	from(
    	select customer_name, branch_city
    	from depositor natural join account natural join branch
    	union
    	select customer_name, branch_city
    	from borrower natural join loan natural join branch) as customer_contracts
	group by branch_city);

-- (n)	Quais são os nomes dos clientes que têm contas em todas as agências do banco?
-- Usar divisão:

select distinct customer_name 
from depositor d
where not exists (
	select branch_name
	from branch
	except
	select branch_name 
	from depositor d2 natural join account
	where d2.customer_name = d.customer_name);
        
    
-- ou
-- Evitar!
select customer_name
from depositor natural join account
group by customer_name
having count(distinct (branch_name)) = (select count(*) from branch);

-- (o)	Quais são os nomes dos clientes que têm conta em todas as agências que existem na mesma cidade onde moram?
select customer_name 
from depositor d natural join customer c	 
where not exists (
	select branch_name
	from branch
	where branch_city = c.customer_city
	except
	select branch_name 
	from depositor d2 natural join account
	where d2.customer_name = d.customer_name);