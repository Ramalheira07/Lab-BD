-- =========================================
-- BASE DE DADOS: CINEMA (PORTUGUÊS)
-- =========================================
CREATE DATABASE cinema_pt;
USE cinema_pt;

-- =========================================
-- 1. WHERE
-- =========================================

-- Selecionar filmes de ação
SELECT * FROM filmes
WHERE genero = 'Ação';

-- EXERCÍCIO:
-- Liste todos os filmes lançados antes de 2010


-- =========================================
-- 2. DISTINCT
-- =========================================

-- Nacionalidades únicas
SELECT DISTINCT nacionalidade FROM atores;

-- EXERCÍCIO:
-- Liste todos os géneros de filmes sem repetição


-- =========================================
-- 3. LIKE
-- =========================================

-- Filmes que começam com "V"
SELECT * FROM filmes
WHERE titulo LIKE 'V%';

-- EXERCÍCIO:
-- Liste atores cujo nome termina com "s"


-- =========================================
-- 4. BETWEEN
-- =========================================

-- Filmes entre 1990 e 2015
SELECT * FROM filmes
WHERE ano_lancamento BETWEEN 1990 AND 2015;

-- EXERCÍCIO:
-- Liste atores nascidos entre 1960 e 1985


-- =========================================
-- 5. ORDER BY
-- =========================================

-- Filmes do mais recente para o mais antigo
SELECT * FROM filmes
ORDER BY ano_lancamento DESC;

-- EXERCÍCIO:
-- Liste atores por nacionalidade em ordem alfabética


-- =========================================
-- 6. UNION
-- =========================================
-- UNION → remove valores duplicados
-- UNION ALL → mantém os duplicados

-- Lista de nomes (atores + estúdios)
SELECT nome FROM atores
UNION
SELECT nome FROM estudios;

-- EXERCÍCIO:
-- Faça a mesma consulta mas mantendo valores duplicados
SELECT nome FROM atores
UNION ALL
SELECT nome FROM estudios;

-- =========================================
-- 7. NULL e NOT NULL
-- =========================================

-- Atores sem data de nascimento
SELECT * FROM atores
WHERE data_nascimento IS NULL;

-- EXERCÍCIO:
-- Liste atores que possuem data de nascimento preenchida


-- =========================================
-- 8. FUNÇÕES AGREGADORAS + GROUP BY
-- =========================================

-- Total de filmes por género
SELECT genero, COUNT(*) AS total
FROM filmes
GROUP BY genero;

-- EXERCÍCIO:
-- Conte quantos atores existem por nacionalidade


-- Média de ano de lançamento
SELECT AVG(ano_lancamento) FROM filmes;

-- EXERCÍCIO:
-- Descubra o ano mais recente de lançamento


-- =========================================
-- 9. DELETE
-- =========================================

-- Remover ator específico
DELETE FROM atores
WHERE id = 4;

-- EXERCÍCIO:
-- Remova todos os filmes do género "Aventura"


-- =========================================
-- 10. TRUNCATE
-- =========================================

-- Limpar tabela
TRUNCATE TABLE filmes_atores;

-- EXERCÍCIO:
-- Limpe a tabela de atores


-- =========================================
-- 11. DROP
-- =========================================

-- Apagar tabela
DROP TABLE atores;

-- EXERCÍCIO:
-- Apague a tabela filmes


-- =========================================
-- FIM DO SCRIPT
-- =========================================