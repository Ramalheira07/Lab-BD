-- =========================================
-- 1. CRIAÇÃO DA BASE DE DADOS
-- =========================================
CREATE DATABASE cinema;
USE cinema;

-- =========================================
-- 2. TABELAS
-- =========================================

-- Tabela de estúdios
CREATE TABLE estudios (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    pais VARCHAR(50),
    ano_fundacao INT
);

-- Tabela de filmes
CREATE TABLE filmes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    titulo VARCHAR(150) NOT NULL,
    ano_lancamento INT,
    genero VARCHAR(50),
    estudio_id INT,
    FOREIGN KEY (estudio_id) REFERENCES estudios(id)
);

-- Tabela de atores
CREATE TABLE atores (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    data_nascimento DATE,
    nacionalidade VARCHAR(50)
);

-- Tabela de relacionamento (filmes ↔ atores)
CREATE TABLE filmes_atores (
    filme_id INT,
    ator_id INT,
    nome_personagem VARCHAR(100),
    PRIMARY KEY (filme_id, ator_id),
    FOREIGN KEY (filme_id) REFERENCES filmes(id),
    FOREIGN KEY (ator_id) REFERENCES atores(id)
);

