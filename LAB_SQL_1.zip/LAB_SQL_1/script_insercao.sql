-- =========================================
-- 3. INSERÇÃO DE DADOS
-- =========================================

-- Estúdios
INSERT INTO estudios (nome, pais, ano_fundacao) VALUES
('Warner Bros', 'EUA', 1923),
('Marvel Studios', 'EUA', 1993),
('Universal Pictures', 'EUA', 1912);

-- Filmes
INSERT INTO filmes (titulo, ano_lancamento, genero, estudio_id) VALUES
('A Origem', 2010, 'Ficção Científica', 1),
('Vingadores: Ultimato', 2019, 'Ação', 2),
('Parque dos Dinossauros', 1993, 'Aventura', 3);

-- Atores
INSERT INTO atores (nome, data_nascimento, nacionalidade) VALUES
('Leonardo DiCaprio', '1974-11-11', 'EUA'),
('Robert Downey Jr.', '1965-04-04', 'EUA'),
('Chris Evans', '1981-06-13', 'EUA'),
('Sam Neill', '1947-09-14', 'Nova Zelândia');

-- Relacionamento filmes ↔ atores
INSERT INTO filmes_atores (filme_id, ator_id, nome_personagem) VALUES
(1, 1, 'Cobb'),
(2, 2, 'Homem de Ferro'),
(2, 3, 'Capitão América'),
(3, 4, 'Dr. Alan Grant');

-- =========================================
-- 4. CONSULTA DE TESTE
-- =========================================

SELECT 
    f.titulo AS filme,
    e.nome AS estudio,
    a.nome AS ator,
    fa.nome_personagem
FROM filmes f
JOIN estudios e ON f.estudio_id = e.id
JOIN filmes_atores fa ON f.id = fa.filme_id
JOIN atores a ON fa.ator_id = a.id;